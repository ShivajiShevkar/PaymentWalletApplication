package com.premaseem.interpreterPattern;

import java.util.Date;

public class Context {
	public String expression;
	public Date date;

	public String getExpression() {
		return expression;
	}

	public void setExpression(String expression) {
		this.expression = expression;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
