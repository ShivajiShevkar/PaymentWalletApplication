package headfirst.command.remote;

public class NoCommand implements Command {
	public void execute() { }
}
