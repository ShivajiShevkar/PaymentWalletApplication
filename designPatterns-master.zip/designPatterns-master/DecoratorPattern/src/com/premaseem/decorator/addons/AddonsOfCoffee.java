package com.premaseem.decorator.addons;

import com.premaseem.decorator.AbstractCoffeRoot;

public abstract class AddonsOfCoffee extends AbstractCoffeRoot  {

@Override
abstract public String getDescription();
}
