package com.premaseem.factory;

public class MexicanPizza implements PizzaBase {

	@Override
    public double getCost() {
	    // TODO Auto-generated method stub
	    return 13;
    }

	@Override
    public String getDescription() {
	    // TODO Auto-generated method stub
	    return "Mexican Pizza";
    }

}
