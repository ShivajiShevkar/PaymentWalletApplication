package com.premaseem.bridgePattern;

public interface TVRemoteOld {

void setChannel();
void increaseVolume();
void decreaseVolume();

}


class SonyRemote implements TVRemoteOld{

	@Override
    public void setChannel() {
	    // TODO Auto-generated method stub
	    
    }

	@Override
    public void increaseVolume() {
	    // TODO Auto-generated method stub
	    
    }

	@Override
    public void decreaseVolume() {
	    // TODO Auto-generated method stub
	    
    }}

class PhilipRemot implements TVRemoteOld{

	@Override
    public void setChannel() {
	    // TODO Auto-generated method stub
	    
    }

	@Override
    public void increaseVolume() {
	    // TODO Auto-generated method stub
	    
    }

	@Override
    public void decreaseVolume() {
	    // TODO Auto-generated method stub
	    
    }
	
}